﻿function deleteTodo(i) {
    $.ajax({
        url: '/Home/Delete',
        type: 'POST',
        data: { id: i },
        success: function () {
            window.location.reload();
        },
        error: function (xhr, status, error) {
            console.error("Delete failed:", error);
        }
    });
}

function populateForm(i) {
    $.ajax({
        url: '/Home/PopulateForm',
        type: 'GET',
        data: { id: i },
        dataType: 'json',
        success: function (response) {
            $('#Todo_Name').val(response.name);
            $('#Todo_Id').val(response.id);
            $('#form-button').val('Update Todo');
            $('#form-action').attr('action', '/Home/Update');

            $('#form-action').addClass('form-animate');
            setTimeout(() => $('#form-action').removeClass('form-animate'), 800);
        },
        error: function (xhr, status, error) {
            console.error("Failed to populate form:", error);
        }
    });
}

function resetForm() {
    $('#Todo_Name').val('');
    $('#Todo_Id').val('');
    $('#form-button').val('Add Todo');
    $('#form-action').attr('action', '/Home/Insert');
}