using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using Todo.Models;
using Todo.Models.ViewModels;

namespace Todo.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            var viewModel = GetAllTodos();
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult Insert(TodoItem todo)
        {
            Console.WriteLine($"INSERTING: Id={todo.Id}, Name={todo.Name}");

            if (string.IsNullOrWhiteSpace(todo.Name))
            {
                Console.WriteLine("Insert failed: Name is empty.");
                return RedirectToAction("Index");
            }

            using (var con = new SqliteConnection("Data Source=db.sqlite"))
            {
                using (var tableCmd = con.CreateCommand())
                {
                    con.Open();
                    tableCmd.CommandText = "INSERT INTO todo (name) VALUES (@name)";
                    tableCmd.Parameters.AddWithValue("@name", todo.Name);

                    try
                    {
                        tableCmd.ExecuteNonQuery();
                        Console.WriteLine("Insert successful.");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Insert failed: " + ex.Message);
                    }
                }
            }

            return RedirectToAction("Index");
        }

        [HttpPost]
        public JsonResult Delete(int id)
        {
            using (var con = new SqliteConnection("Data Source=db.sqlite"))
            {
                using (var tableCmd = con.CreateCommand())
                {
                    con.Open();
                    tableCmd.CommandText = "DELETE FROM todo WHERE Id = @id";
                    tableCmd.Parameters.AddWithValue("@id", id);
                    tableCmd.ExecuteNonQuery();
                }
            }

            return Json(new { success = true, deletedId = id });
        }

        [HttpGet]
        public JsonResult PopulateForm(int id)
        {
            TodoItem todo = new();

            using (var con = new SqliteConnection("Data Source=db.sqlite"))
            {
                using (var tableCmd = con.CreateCommand())
                {
                    con.Open();
                    tableCmd.CommandText = "SELECT * FROM todo WHERE Id = @id";
                    tableCmd.Parameters.AddWithValue("@id", id);

                    using (var reader = tableCmd.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            reader.Read();
                            todo.Id = reader.GetInt32(0);
                            todo.Name = reader.GetString(1);
                        }
                    }
                }
            }

            return Json(new { id = todo.Id, name = todo.Name });
        }

        [HttpPost]
        public IActionResult Update(TodoItem todo)
        {
            using (var con = new SqliteConnection("Data Source=db.sqlite"))
            {
                using (var tableCmd = con.CreateCommand())
                {
                    con.Open();
                    tableCmd.CommandText = "UPDATE todo SET name = @name WHERE Id = @id";
                    tableCmd.Parameters.AddWithValue("@name", todo.Name);
                    tableCmd.Parameters.AddWithValue("@id", todo.Id);

                    try
                    {
                        tableCmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
            }

            return RedirectToAction("Index");
        }

        internal TodoViewModel GetAllTodos()
        {
            List<TodoItem> todoList = new();

            using (var con = new SqliteConnection("Data Source=db.sqlite"))
            {
                using (var tableCmd = con.CreateCommand())
                {
                    con.Open();
                    tableCmd.CommandText = "SELECT * FROM todo";

                    using (var reader = tableCmd.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                todoList.Add(new TodoItem
                                {
                                    Id = reader.GetInt32(0),
                                    Name = reader.GetString(1)
                                });
                            }
                        }
                    }
                }
            }

            return new TodoViewModel { TodoList = todoList };
        }
    }
}